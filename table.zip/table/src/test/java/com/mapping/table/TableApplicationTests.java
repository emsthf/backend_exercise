package com.mapping.table;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TableApplicationTests {

	@Test
	void contextLoads() {
	}

}
