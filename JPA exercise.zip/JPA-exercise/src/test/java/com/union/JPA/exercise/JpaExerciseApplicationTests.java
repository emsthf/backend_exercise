package com.union.JPA.exercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaExerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
